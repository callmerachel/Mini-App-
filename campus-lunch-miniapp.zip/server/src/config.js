// Tất cả business rule (BR-01..BR-10) cấu hình qua ENV — mặc định theo PRD §11.1
const env = process.env;
const list = (v, d = "") => (v ?? d).split(",").map((s) => s.trim()).filter(Boolean);

export const config = {
  port: Number(env.PORT || 8080),
  appEnv: env.APP_ENV || "testing", // development | testing | production
  databaseUrl: env.DATABASE_URL,
  jwtSecret: env.JWT_SECRET || "change-me",

  // Auth: "zalo" = decode access token qua Graph API (bản chạy trong Zalo)
  //       "dev"  = cho phép login giả lập bằng devUserId (chỉ dùng khi dev trên trình duyệt)
  authMode: env.AUTH_MODE || "zalo",
  zaloAppSecret: env.ZALO_APP_SECRET || "",
  staffZaloIds: list(env.STAFF_ZALO_IDS),

  // Payment: "checkout" = Zalo Checkout SDK (sandbox/production do CHECKOUT_METHOD quyết định)
  //          "mock"     = giả lập thanh toán trong server (không cần merchant account)
  paymentMode: env.PAYMENT_MODE || "mock",
  checkoutPrivateKey: env.CHECKOUT_PRIVATE_KEY || "",
  checkoutMethod: env.CHECKOUT_METHOD || "", // ví dụ ZALOPAY_SANDBOX — xác nhận tên method trong trang Checkout SDK

  corsOrigins: list(env.CORS_ORIGINS, "https://h5.zdn.vn,https://h5.zadn.vn,http://localhost:3000"),

  rules: {
    openTime: env.ORDER_OPEN || "07:00", // BR-01
    cutoffTime: env.ORDER_CUTOFF || "10:30", // BR-01
    slotStart: env.SLOT_START || "11:00", // BR-02
    slotEnd: env.SLOT_END || "13:30", // BR-02
    slotMinutes: Number(env.SLOT_MINUTES || 15), // BR-02
    slotCapacity: Number(env.SLOT_CAPACITY || 20), // BR-02
    leadMinutes: Number(env.LEAD_MINUTES || 30), // BR-03
    maxQtyPerDish: Number(env.MAX_QTY || 5), // BR-04
    holdMinutes: Number(env.HOLD_MINUTES || 10), // BR-05
    noShowTime: env.NO_SHOW_TIME || "13:30", // BR-07
    closedWeekdays: list(env.CLOSED_WEEKDAYS, "0,6").map(Number), // 0=CN, 6=T7
  },
};

export const isProd = () => config.appEnv === "production";
