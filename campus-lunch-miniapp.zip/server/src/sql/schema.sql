-- ORD · 9 entities (PRD §6)
CREATE TABLE IF NOT EXISTS customers (
  zalo_id       TEXT PRIMARY KEY,
  display_name  TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS staff (
  zalo_id       TEXT PRIMARY KEY,
  role          TEXT NOT NULL CHECK (role IN ('manager','kitchen')),
  display_name  TEXT
);

CREATE TABLE IF NOT EXISTS menu_items (
  id               SERIAL PRIMARY KEY,
  name             TEXT NOT NULL,
  description      TEXT NOT NULL DEFAULT '' CHECK (char_length(description) <= 80),
  price            INTEGER NOT NULL CHECK (price > 0),
  image_url        TEXT,
  category         TEXT NOT NULL DEFAULT 'Món chính',
  default_portions INTEGER NOT NULL DEFAULT 30 CHECK (default_portions >= 0),
  active           BOOLEAN NOT NULL DEFAULT true,
  sort_order       INTEGER NOT NULL DEFAULT 0,
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS daily_stock (
  menu_item_id   INTEGER NOT NULL REFERENCES menu_items(id),
  day            DATE NOT NULL,
  portions_total INTEGER NOT NULL,
  portions_left  INTEGER NOT NULL CHECK (portions_left >= 0),
  sold_out       BOOLEAN NOT NULL DEFAULT false,
  PRIMARY KEY (menu_item_id, day)
);

CREATE TABLE IF NOT EXISTS pickup_slots (
  id           SERIAL PRIMARY KEY,
  day          DATE NOT NULL,
  start_time   TEXT NOT NULL,         -- 'HH:MM'
  capacity     INTEGER NOT NULL,
  booked_count INTEGER NOT NULL DEFAULT 0 CHECK (booked_count >= 0),
  UNIQUE (day, start_time)
);

CREATE TABLE IF NOT EXISTS orders (
  id                  BIGSERIAL PRIMARY KEY,
  day                 DATE NOT NULL,
  order_code          CHAR(4) NOT NULL,
  customer_id         TEXT NOT NULL REFERENCES customers(zalo_id),
  customer_name       TEXT,
  slot_id             INTEGER NOT NULL REFERENCES pickup_slots(id),
  status              TEXT NOT NULL,
  total               INTEGER NOT NULL,
  hold_expires_at     TIMESTAMPTZ,
  hold_released       BOOLEAN NOT NULL DEFAULT false,
  needs_stock_confirm BOOLEAN NOT NULL DEFAULT false,
  cancel_reason       TEXT,
  paid_at             TIMESTAMPTZ,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (day, order_code)
);
CREATE INDEX IF NOT EXISTS orders_customer_idx ON orders (customer_id, day);
CREATE INDEX IF NOT EXISTS orders_day_status_idx ON orders (day, status);

CREATE TABLE IF NOT EXISTS order_items (
  id           BIGSERIAL PRIMARY KEY,
  order_id     BIGINT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  menu_item_id INTEGER NOT NULL REFERENCES menu_items(id),
  name         TEXT NOT NULL,
  unit_price   INTEGER NOT NULL,                        -- BR-09 snapshot
  quantity     INTEGER NOT NULL CHECK (quantity BETWEEN 1 AND 5),
  note         TEXT CHECK (char_length(note) <= 100),
  line_total   INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS payments (
  id                BIGSERIAL PRIMARY KEY,
  order_id          BIGINT NOT NULL REFERENCES orders(id),
  provider          TEXT NOT NULL,
  provider_txn_id   TEXT NOT NULL UNIQUE,                -- idempotent key
  provider_order_id TEXT,
  amount            INTEGER NOT NULL,
  result_code       INTEGER,
  status            TEXT NOT NULL,                       -- success | failed
  raw               JSONB,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS status_logs (
  id          BIGSERIAL PRIMARY KEY,
  order_id    BIGINT NOT NULL REFERENCES orders(id),
  from_status TEXT,
  to_status   TEXT NOT NULL,
  actor       TEXT NOT NULL,
  reason      TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
