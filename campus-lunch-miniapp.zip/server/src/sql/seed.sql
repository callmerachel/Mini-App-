-- Seed theo PRD §12: 10 món, 1 món chỉ còn 1 phần, 1 món hết
INSERT INTO menu_items (id, name, description, price, category, default_portions, sort_order) VALUES
 (1,  'Cơm tấm sườn',       'Sườn nướng than, bì, chả trứng, mỡ hành', 45000, 'Cơm', 40, 1),
 (2,  'Bún bò Huế',         'Nước dùng sả ruốc, bắp bò, giò heo',       50000, 'Bún - Phở', 30, 2),
 (3,  'Phở bò',             'Phở tái nạm, nước dùng hầm xương 8 tiếng', 50000, 'Bún - Phở', 30, 3),
 (4,  'Cơm gà xối mỡ',      'Đùi gà giòn da, cơm chiên nghệ, dưa leo',  45000, 'Cơm', 30, 4),
 (5,  'Cơm chiên dương châu','Tôm, lạp xưởng, trứng, đậu Hà Lan',        40000, 'Cơm', 25, 5),
 (6,  'Bún thịt nướng',     'Thịt nướng, chả giò, rau sống, nước mắm',  42000, 'Bún - Phở', 25, 6),
 (7,  'Mì xào hải sản',     'Mì trứng, mực, tôm, cải ngọt',             48000, 'Mì', 20, 7),
 (8,  'Cơm cá kho tộ',      'Cá basa kho tiêu, canh chua, rau luộc',    45000, 'Cơm', 1, 8),
 (9,  'Cơm chay thập cẩm',  'Đậu hũ sốt cà, nấm xào, canh rau củ',      35000, 'Chay', 15, 9),
 (10, 'Bánh canh cua',      'Bánh canh bột lọc, cua đồng, chả cua',     50000, 'Bún - Phở', 0, 10)
ON CONFLICT (id) DO NOTHING;
SELECT setval('menu_items_id_seq', (SELECT MAX(id) FROM menu_items));
