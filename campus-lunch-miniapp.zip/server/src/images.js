// Ảnh minh hoạ nhẹ (< 2 KB/ảnh) cho seed data. Thay bằng ảnh thật (≤150 KB) qua cột image_url.
const PALETTE = [["#FFE7C2", "#E08A1E"], ["#FFD9D2", "#D1503A"], ["#E3F1DF", "#4E8C3A"], ["#FFF1BF", "#B98A00"], ["#E6EEFF", "#3C63C9"]];
const BOWL = `<ellipse cx="100" cy="112" rx="70" ry="14" fill="rgba(0,0,0,.08)"/><path d="M30 80h140c0 34-31 52-70 52S30 114 30 80z" fill="#fff"/><path d="M30 80h140" stroke="rgba(0,0,0,.15)" stroke-width="3"/>`;
export function dishSvg(id, name = "") {
  const [bg, fg] = PALETTE[(Number(id) || 0) % PALETTE.length];
  const initial = (name.trim()[0] || "C").toUpperCase();
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 150"><rect width="200" height="150" fill="${bg}"/>
<circle cx="100" cy="72" r="34" fill="${fg}" opacity=".9"/>${BOWL}
<text x="100" y="84" text-anchor="middle" font-family="Arial, sans-serif" font-size="34" font-weight="700" fill="#fff">${initial}</text></svg>`;
}
