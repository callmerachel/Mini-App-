import crypto from "node:crypto";
import { config } from "./config.js";
import { clock, vn, toMin, toHHMM } from "./clock.js";
import { q, tx } from "./db.js";

const R = config.rules;
export class AppError extends Error {
  constructor(status, code, message, extra = {}) { super(message); Object.assign(this, { status, code, extra }); }
}

// ---------- Ngày bán hàng ----------
export function dayState(now = vn()) {
  if (R.closedWeekdays.includes(now.weekday)) return { open: false, reason: "closed_day", message: "Hôm nay quán nghỉ" };
  if (now.minutes < toMin(R.openTime)) return { open: false, reason: "before_open", message: `Quán nhận đặt từ ${R.openTime}` };
  if (now.minutes >= toMin(R.cutoffTime)) return { open: false, reason: "after_cutoff", message: "Đã hết giờ đặt hôm nay" };
  return { open: true, reason: null, message: null };
}

// Tạo DailyStock + PickupSlot cho ngày (idempotent). Store "publish" menu = tồn kho mặc định.
export async function ensureDay(day, client = { query: q }) {
  await client.query(
    `INSERT INTO daily_stock (menu_item_id, day, portions_total, portions_left)
     SELECT id, $1, default_portions, default_portions FROM menu_items WHERE active
     ON CONFLICT DO NOTHING`, [day]);
  const starts = [];
  for (let m = toMin(R.slotStart); m < toMin(R.slotEnd); m += R.slotMinutes) starts.push(toHHMM(m));
  await client.query(
    `INSERT INTO pickup_slots (day, start_time, capacity)
     SELECT $1, s, $2 FROM unnest($3::text[]) s ON CONFLICT DO NOTHING`, [day, R.slotCapacity, starts]);
}

export async function getMenu() {
  const now = vn();
  await ensureDay(now.date);
  const { rows } = await q(
    `SELECT m.id, m.name, m.description, m.price, m.image_url, m.category,
            s.portions_left, s.sold_out
       FROM menu_items m JOIN daily_stock s ON s.menu_item_id = m.id AND s.day = $1
      WHERE m.active ORDER BY m.sort_order, m.id`, [now.date]);
  const state = dayState(now);
  return {
    date: now.date, serverTime: now.hhmm, ...state, cutoff: R.cutoffTime,
    maxQtyPerDish: R.maxQtyPerDish,
    items: state.reason === "closed_day" ? [] : rows.map((r) => ({
      id: r.id, name: r.name, description: r.description, price: r.price, category: r.category,
      imageUrl: r.image_url || `/images/${r.id}.svg`,
      portionsLeft: r.sold_out ? 0 : r.portions_left,
      soldOut: r.sold_out || r.portions_left <= 0,
    })),
  };
}

export async function getSlots() {
  const now = vn();
  await ensureDay(now.date);
  const { rows } = await q(`SELECT id, start_time, capacity, booked_count FROM pickup_slots WHERE day=$1 ORDER BY start_time`, [now.date]);
  return rows.map((s) => {
    const remaining = s.capacity - s.booked_count;
    const tooSoon = toMin(s.start_time) - now.minutes < R.leadMinutes;
    return {
      id: s.id, start: s.start_time, end: toHHMM(toMin(s.start_time) + R.slotMinutes), remaining,
      disabled: remaining <= 0 || tooSoon,
      disabledReason: remaining <= 0 ? "full" : tooSoon ? "too_soon" : null,
    };
  });
}

// ---------- Tạo đơn: giữ tồn kho + slot trong 10 phút (BR-05) ----------
async function releaseHold(client, orderId) {
  const { rows } = await client.query(`UPDATE orders SET hold_released=true WHERE id=$1 AND NOT hold_released RETURNING day, slot_id`, [orderId]);
  if (!rows.length) return;
  const { day, slot_id } = rows[0];
  await client.query(
    `UPDATE daily_stock s SET portions_left = s.portions_left + i.quantity
       FROM order_items i WHERE i.order_id=$1 AND s.menu_item_id=i.menu_item_id AND s.day=$2`, [orderId, day]);
  await client.query(`UPDATE pickup_slots SET booked_count = GREATEST(booked_count-1,0) WHERE id=$1`, [slot_id]);
}

export async function logStatus(client, orderId, from, to, actor, reason = null) {
  await client.query(`INSERT INTO status_logs (order_id, from_status, to_status, actor, reason) VALUES ($1,$2,$3,$4,$5)`,
    [orderId, from, to, actor, reason]);
}

export async function createOrder(user, body) {
  const now = vn();
  const state = dayState(now);
  if (!state.open) throw new AppError(409, "ORDERING_CLOSED", state.message);

  const raw = Array.isArray(body?.items) ? body.items : [];
  if (!raw.length) throw new AppError(400, "EMPTY_CART", "Giỏ hàng đang trống");
  const lines = new Map();
  for (const it of raw) {
    const id = Number(it.menuItemId), qty = Number(it.quantity);
    const note = (it.note || "").toString().trim();
    if (!Number.isInteger(id) || !Number.isInteger(qty) || qty < 1 || qty > R.maxQtyPerDish)
      throw new AppError(400, "INVALID_QTY", `Số lượng mỗi món từ 1 đến ${R.maxQtyPerDish}`);
    if (note.length > 100) throw new AppError(400, "NOTE_TOO_LONG", "Ghi chú tối đa 100 ký tự");
    if (lines.has(id)) throw new AppError(400, "DUPLICATE_ITEM", "Món bị lặp trong giỏ");
    lines.set(id, { id, qty, note: note || null, expectedPrice: it.expectedPrice == null ? null : Number(it.expectedPrice) });
  }
  const slotId = Number(body?.slotId);
  if (!slotId) throw new AppError(400, "SLOT_REQUIRED", "Vui lòng chọn giờ nhận món");

  return tx(async (c) => {
    await ensureDay(now.date, c);
    // Hủy các đơn đang chờ thanh toán cũ của khách → trả lại tồn kho (tránh giữ hàng kép)
    const stale = await c.query(`SELECT id FROM orders WHERE customer_id=$1 AND day=$2 AND status='pending_payment'`, [user.sub, now.date]);
    for (const o of stale.rows) {
      await c.query(`UPDATE orders SET status='expired', updated_at=now() WHERE id=$1`, [o.id]);
      await releaseHold(c, o.id);
      await logStatus(c, o.id, "pending_payment", "expired", user.sub, "replaced_by_new_order");
    }

    const ids = [...lines.keys()];
    const menu = await c.query(`SELECT id, name, price FROM menu_items WHERE id = ANY($1) AND active`, [ids]);
    if (menu.rows.length !== ids.length) throw new AppError(409, "ITEM_UNAVAILABLE", "Có món không còn trong thực đơn");

    // US-03: giá thay đổi → báo trước khi thanh toán
    const priceChanges = menu.rows
      .filter((m) => { const l = lines.get(m.id); return l.expectedPrice != null && l.expectedPrice !== m.price; })
      .map((m) => ({ menuItemId: m.id, name: m.name, oldPrice: lines.get(m.id).expectedPrice, newPrice: m.price }));
    if (priceChanges.length) throw new AppError(409, "PRICE_CHANGED", "Giá món đã thay đổi", { priceChanges });

    // Giữ tồn kho nguyên tử (edge case: 2 người cùng mua phần cuối)
    for (const m of menu.rows) {
      const l = lines.get(m.id);
      const r = await c.query(
        `UPDATE daily_stock SET portions_left = portions_left - $1
          WHERE menu_item_id=$2 AND day=$3 AND NOT sold_out AND portions_left >= $1 RETURNING portions_left`,
        [l.qty, m.id, now.date]);
      if (!r.rowCount) {
        const left = await c.query(`SELECT CASE WHEN sold_out THEN 0 ELSE portions_left END AS left FROM daily_stock WHERE menu_item_id=$1 AND day=$2`, [m.id, now.date]);
        throw new AppError(409, "OUT_OF_STOCK", `${m.name}: ${left.rows[0]?.left ? `chỉ còn ${left.rows[0].left} phần` : "Hết món"}`,
          { menuItemId: m.id, portionsLeft: left.rows[0]?.left ?? 0 });
      }
    }

    // Slot: đủ chỗ + đủ lead time (BR-02, BR-03)
    const slot = await c.query(`SELECT start_time FROM pickup_slots WHERE id=$1 AND day=$2`, [slotId, now.date]);
    if (!slot.rowCount) throw new AppError(400, "SLOT_INVALID", "Giờ nhận không hợp lệ");
    if (toMin(slot.rows[0].start_time) - now.minutes < R.leadMinutes)
      throw new AppError(409, "SLOT_TOO_SOON", `Khung ${slot.rows[0].start_time} cần đặt trước ít nhất ${R.leadMinutes} phút`, { slotId });
    const sr = await c.query(`UPDATE pickup_slots SET booked_count=booked_count+1 WHERE id=$1 AND booked_count < capacity RETURNING id`, [slotId]);
    if (!sr.rowCount) throw new AppError(409, "SLOT_FULL", `Khung ${slot.rows[0].start_time} đã đủ đơn, vui lòng chọn khung khác`, { slotId });

    const total = menu.rows.reduce((s, m) => s + m.price * lines.get(m.id).qty, 0); // tính ở server
    const holdUntil = new Date(clock.now().getTime() + R.holdMinutes * 60000);
    let order;
    for (let i = 0; i < 20 && !order; i++) {
      const code = String(crypto.randomInt(1000, 10000));
      const ins = await c.query(
        `INSERT INTO orders (day, order_code, customer_id, customer_name, slot_id, status, total, hold_expires_at)
         VALUES ($1,$2,$3,$4,$5,'pending_payment',$6,$7) ON CONFLICT (day, order_code) DO NOTHING RETURNING id`,
        [now.date, code, user.sub, user.name || null, slotId, total, holdUntil]);
      if (ins.rowCount) order = ins.rows[0];
    }
    if (!order) throw new AppError(503, "CODE_EXHAUSTED", "Không tạo được mã đơn, thử lại");
    for (const m of menu.rows) {
      const l = lines.get(m.id);
      await c.query(
        `INSERT INTO order_items (order_id, menu_item_id, name, unit_price, quantity, note, line_total) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [order.id, m.id, m.name, m.price, l.qty, l.note, m.price * l.qty]);
    }
    await logStatus(c, order.id, null, "pending_payment", user.sub);
    return getOrder(order.id, c);
  });
}

export async function getOrder(id, client = { query: q }) {
  const { rows } = await client.query(
    `SELECT o.*, s.start_time FROM orders o JOIN pickup_slots s ON s.id=o.slot_id WHERE o.id=$1`, [id]);
  if (!rows.length) return null;
  const items = await client.query(`SELECT menu_item_id, name, unit_price, quantity, note, line_total FROM order_items WHERE order_id=$1 ORDER BY id`, [id]);
  return formatOrder(rows[0], items.rows);
}

export function formatOrder(o, items) {
  return {
    id: Number(o.id), day: o.day, code: o.order_code, status: o.status, total: o.total,
    customerId: o.customer_id,
    customerName: o.customer_name || `Khách ${o.order_code}`,
    slot: { id: o.slot_id, start: o.start_time, end: toHHMM(toMin(o.start_time) + R.slotMinutes) },
    holdExpiresAt: o.hold_expires_at, needsStockConfirm: o.needs_stock_confirm, cancelReason: o.cancel_reason,
    paidAt: o.paid_at, createdAt: o.created_at,
    items: items.map((i) => ({ menuItemId: i.menu_item_id, name: i.name, unitPrice: i.unit_price, quantity: i.quantity, note: i.note, lineTotal: i.line_total })),
  };
}

export async function listOrders(where, params) {
  const { rows } = await q(
    `SELECT o.*, s.start_time FROM orders o JOIN pickup_slots s ON s.id=o.slot_id WHERE ${where} ORDER BY s.start_time, o.paid_at NULLS LAST, o.id`, params);
  if (!rows.length) return [];
  const items = await q(`SELECT * FROM order_items WHERE order_id = ANY($1) ORDER BY id`, [rows.map((r) => r.id)]);
  return rows.map((o) => formatOrder(o, items.rows.filter((i) => String(i.order_id) === String(o.id))));
}

// ---------- Thanh toán ----------
// Checkout SDK: mac = HMAC-SHA256(privateKey, "amount=..&desc=..&extradata=..&item=..&method=..") — key sắp xếp a→z,
// giá trị object được JSON.stringify. [Cần đối chiếu docs Checkout SDK > createOrder trước khi go-live]
export function buildCheckoutParams(order) {
  const params = {
    amount: order.total,
    desc: `Com trua ${order.code} - ${order.slot.start}`,
    item: order.items.map((i) => ({ id: String(i.menuItemId), amount: i.lineTotal })),
    extradata: JSON.stringify({ orderId: order.id }),
  };
  if (config.checkoutMethod) params.method = JSON.stringify({ id: config.checkoutMethod, isCustom: false });
  const dataMac = Object.keys(params).sort()
    .map((k) => `${k}=${typeof params[k] === "object" ? JSON.stringify(params[k]) : params[k]}`).join("&");
  params.mac = crypto.createHmac("sha256", config.checkoutPrivateKey).update(dataMac).digest("hex");
  return params;
}

// Callback (Notify URL): mac = HMAC-SHA256(privateKey,
// "appId=..&amount=..&description=..&orderId=..&message=..&resultCode=..&transId=..") [Cần đối chiếu docs]
export function verifyCallbackMac({ data, mac }) {
  if (!data || !mac) return false;
  const s = `appId=${data.appId}&amount=${data.amount}&description=${data.description}&orderId=${data.orderId}&message=${data.message}&resultCode=${data.resultCode}&transId=${data.transId}`;
  const expected = crypto.createHmac("sha256", config.checkoutPrivateKey).update(s).digest("hex");
  return expected.length === mac.length && crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(mac));
}

// Xử lý kết quả thanh toán — idempotent theo provider_txn_id (TC-11)
export async function processPaymentResult({ provider, orderId, transId, providerOrderId, amount, resultCode, raw }) {
  return tx(async (c) => {
    const o = await c.query(`SELECT * FROM orders WHERE id=$1 FOR UPDATE`, [orderId]);
    if (!o.rowCount) throw new AppError(404, "ORDER_NOT_FOUND", "Không tìm thấy đơn");
    const order = o.rows[0];
    const success = Number(resultCode) === 1;
    const ins = await c.query(
      `INSERT INTO payments (order_id, provider, provider_txn_id, provider_order_id, amount, result_code, status, raw)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT (provider_txn_id) DO NOTHING RETURNING id`,
      [orderId, provider, String(transId), providerOrderId || null, Number(amount), Number(resultCode), success ? "success" : "failed", raw || null]);
    if (!ins.rowCount) return { duplicate: true, status: order.status };
    if (!success) return { duplicate: false, status: order.status }; // giữ Pending payment, cho phép thử lại

    if (Number(amount) !== order.total) {
      await logStatus(c, orderId, order.status, order.status, "payment", `amount_mismatch:${amount}`);
      return { duplicate: false, status: order.status, flagged: "amount_mismatch" };
    }
    if (order.status === "pending_payment" || order.status === "expired") {
      const late = order.hold_released; // thanh toán về sau khi đã nhả giữ hàng → cờ cho quán xác nhận tồn
      await c.query(`UPDATE orders SET status='paid', paid_at=now(), needs_stock_confirm=$2, updated_at=now() WHERE id=$1`, [orderId, late]);
      await logStatus(c, orderId, order.status, "paid", "payment", late ? "late_payment_after_hold_release" : null);
      return { duplicate: false, status: "paid" };
    }
    return { duplicate: false, status: order.status };
  });
}

// ---------- Quán cập nhật trạng thái (forward-only, US-08) ----------
const NEXT = {
  paid: ["preparing", "cancelled_by_store"],
  preparing: ["ready", "cancelled_by_store"],
  ready: ["picked_up", "no_show"],
};

export async function updateStatus(orderId, to, staffId, { code, reason } = {}) {
  return tx(async (c) => {
    const o = await c.query(`SELECT * FROM orders WHERE id=$1 FOR UPDATE`, [orderId]);
    if (!o.rowCount) throw new AppError(404, "ORDER_NOT_FOUND", "Không tìm thấy đơn");
    const cur = o.rows[0];
    if (!(NEXT[cur.status] || []).includes(to))
      throw new AppError(409, "INVALID_TRANSITION", `Không thể chuyển từ ${cur.status} sang ${to}`);
    if (to === "picked_up" && String(code || "").trim() !== cur.order_code)
      throw new AppError(422, "WRONG_CODE", "Sai mã đơn");
    if (to === "cancelled_by_store" && !reason) throw new AppError(400, "REASON_REQUIRED", "Cần nhập lý do huỷ");
    await c.query(`UPDATE orders SET status=$2, cancel_reason=COALESCE($3, cancel_reason), updated_at=now() WHERE id=$1`, [orderId, to, reason || null]);
    if (to === "cancelled_by_store") await releaseHold(c, orderId);
    await logStatus(c, orderId, cur.status, to, staffId, reason);
    return getOrder(orderId, c);
  });
}

// ---------- Job định kỳ ----------
export async function runJobs() {
  const now = vn();
  // BR-05: hết 10 phút chờ thanh toán → Expired + nhả giữ hàng
  const exp = await q(`SELECT id FROM orders WHERE status='pending_payment' AND hold_expires_at < $1`, [clock.now()]);
  for (const r of exp.rows) {
    await tx(async (c) => {
      const u = await c.query(`UPDATE orders SET status='expired', updated_at=now() WHERE id=$1 AND status='pending_payment' RETURNING id`, [r.id]);
      if (u.rowCount) { await releaseHold(c, r.id); await logStatus(c, r.id, "pending_payment", "expired", "system"); }
    });
  }
  // BR-07: sau 13:30 đơn Ready chưa nhận → No-show
  if (now.minutes >= toMin(R.noShowTime)) {
    const ns = await q(`UPDATE orders SET status='no_show', updated_at=now() WHERE day=$1 AND status='ready' RETURNING id`, [now.date]);
    for (const r of ns.rows) await q(`INSERT INTO status_logs (order_id, from_status, to_status, actor) VALUES ($1,'ready','no_show','system')`, [r.id]);
  }
  // TODO(reconciliation, PRD §13.3): đối soát đơn pending với Checkout (checkTransaction/getOrderStatus server-side) mỗi 5 phút
}
