import express from "express";
import { config, isProd } from "./config.js";
import { clock, vn } from "./clock.js";
import { q } from "./db.js";
import { login, requireUser, requireStaff, syncStaffWhitelist, roleOf } from "./auth.js";
import {
  AppError, getMenu, getSlots, createOrder, getOrder, listOrders, buildCheckoutParams,
  verifyCallbackMac, processPaymentResult, updateStatus, runJobs, ensureDay,
} from "./domain.js";
import { dishSvg } from "./images.js";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
app.set("trust proxy", true);
app.use(express.json({ limit: "100kb" }));

// CORS — trả đúng 1 origin, có xử lý preflight OPTIONS (docs mục 4.3.1 / 4.5.3)
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && config.corsOrigins.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS");
    res.setHeader("Access-Control-Max-Age", "600");
  }
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

app.get("/health", wrap(async (_req, res) => {
  await q("SELECT 1");
  res.json({ ok: true, env: config.appEnv, paymentMode: config.paymentMode, authMode: config.authMode, vnTime: vn().hhmm });
}));

app.get("/images/:id.svg", wrap(async (req, res) => {
  const r = await q(`SELECT name FROM menu_items WHERE id=$1`, [Number(req.params.id) || 0]);
  res.setHeader("Content-Type", "image/svg+xml");
  res.setHeader("Cache-Control", "public, max-age=86400");
  res.send(dishSvg(req.params.id, r.rows[0]?.name));
}));

// ---------- Auth ----------
app.post("/auth/login", wrap(async (req, res) => res.json(await login(req.body))));
app.get("/me", requireUser, wrap(async (req, res) => res.json({ id: req.user.sub, name: req.user.name, role: await roleOf(req.user.sub) })));

// ---------- Customer ----------
app.get("/menu/today", wrap(async (_req, res) => res.json(await getMenu())));
app.get("/slots/today", wrap(async (_req, res) => res.json(await getSlots())));

app.post("/orders", requireUser, wrap(async (req, res) => res.status(201).json(await createOrder(req.user, req.body))));

app.get("/orders/mine", requireUser, wrap(async (req, res) => {
  res.json(await listOrders(`o.customer_id=$1 AND o.day >= ($2::date - 14) AND o.status <> 'expired'`, [req.user.sub, vn().date]));
}));

async function loadOwnOrder(req) {
  const order = await getOrder(Number(req.params.id));
  if (!order) throw new AppError(404, "ORDER_NOT_FOUND", "Không tìm thấy đơn");
  if (order.customerId !== req.user.sub && (await roleOf(req.user.sub)) === "customer")
    throw new AppError(403, "FORBIDDEN", "Đây không phải đơn của bạn");
  return order;
}

app.get("/orders/:id", requireUser, wrap(async (req, res) => res.json(await loadOwnOrder(req))));

app.post("/orders/:id/pay", requireUser, wrap(async (req, res) => {
  const order = await loadOwnOrder(req);
  if (order.status !== "pending_payment") throw new AppError(409, "NOT_PAYABLE", "Đơn không ở trạng thái chờ thanh toán");
  if (new Date(order.holdExpiresAt) < clock.now()) throw new AppError(409, "HOLD_EXPIRED", "Đơn đã quá 10 phút giữ món, vui lòng đặt lại");
  if (config.paymentMode === "checkout") return res.json({ mode: "checkout", params: buildCheckoutParams(order) });
  res.json({ mode: "mock", amount: order.total });
}));

// Notify URL cấu hình trong trang Checkout SDK → https://<api-domain>/payments/callback
app.post("/payments/callback", wrap(async (req, res) => {
  if (!verifyCallbackMac(req.body)) return res.json({ returnCode: -1, returnMessage: "invalid mac" });
  const d = req.body.data;
  let extra = {};
  try { extra = typeof d.extradata === "string" ? JSON.parse(decodeURIComponent(d.extradata)) : d.extradata || {}; } catch {}
  if (!extra.orderId) return res.json({ returnCode: -1, returnMessage: "missing orderId" });
  await processPaymentResult({
    provider: d.method || "checkout", orderId: Number(extra.orderId), transId: d.transId, providerOrderId: d.orderId,
    amount: d.amount, resultCode: d.resultCode, raw: req.body,
  });
  res.json({ returnCode: 1, returnMessage: "Success" });
}));

// ---------- Store (role-gated) ----------
app.get("/store/orders", requireUser, requireStaff(), wrap(async (req, res) => {
  const day = /^\d{4}-\d{2}-\d{2}$/.test(req.query.date || "") ? req.query.date : vn().date;
  await ensureDay(day);
  const orders = await listOrders(`o.day=$1 AND o.status IN ('paid','preparing','ready','picked_up','no_show','cancelled_by_store')`, [day]);
  const prep = await q(
    `SELECT i.menu_item_id, i.name, SUM(i.quantity)::int AS quantity FROM order_items i JOIN orders o ON o.id=i.order_id
      WHERE o.day=$1 AND o.status IN ('paid','preparing','ready','picked_up') GROUP BY 1,2 ORDER BY 3 DESC`, [day]);
  const stock = await q(
    `SELECT m.id, m.name, m.price, s.portions_total, s.portions_left, s.sold_out FROM menu_items m
       JOIN daily_stock s ON s.menu_item_id=m.id AND s.day=$1 ORDER BY m.sort_order, m.id`, [day]);
  res.json({ date: day, serverTime: vn().hhmm, orders, prepSummary: prep.rows, stock: stock.rows });
}));

app.patch("/store/orders/:id/status", requireUser, requireStaff(), wrap(async (req, res) => {
  res.json(await updateStatus(Number(req.params.id), req.body?.to, req.user.sub, { code: req.body?.code, reason: req.body?.reason }));
}));

// Quản lý tồn kho trong ngày (một phần US-09): set số phần / bật tắt Hết món
app.put("/store/menu-items/:id/stock", requireUser, requireStaff(["manager"]), wrap(async (req, res) => {
  const day = vn().date;
  const { portionsLeft, soldOut } = req.body || {};
  if (portionsLeft != null && (!Number.isInteger(portionsLeft) || portionsLeft < 0)) throw new AppError(400, "INVALID", "Số phần không hợp lệ");
  const r = await q(
    `UPDATE daily_stock SET portions_left = COALESCE($3, portions_left),
            portions_total = GREATEST(portions_total, COALESCE($3, portions_left)), sold_out = COALESCE($4, sold_out)
      WHERE menu_item_id=$1 AND day=$2 RETURNING *`, [Number(req.params.id), day, portionsLeft ?? null, soldOut ?? null]);
  if (!r.rowCount) throw new AppError(404, "NOT_FOUND", "Không tìm thấy món");
  res.json(r.rows[0]);
}));

// ---------- Dev/Testing tools (tắt khi APP_ENV=production) ----------
if (!isProd()) {
  app.post("/dev/clock", (req, res) => {
    if (req.body?.reset) clock.reset(); else clock.setVnTime(req.body?.time || "09:00", req.body?.date);
    res.json({ vnTime: vn(), offsetMs: clock.offsetMs() });
  });
  // Giả lập callback thanh toán — dùng cho TC-04/05/06/11 khi PAYMENT_MODE=mock
  app.post("/dev/mock-pay/:id", requireUser, wrap(async (req, res) => {
    if (config.paymentMode !== "mock") throw new AppError(400, "NOT_MOCK", "Server đang dùng Checkout SDK thật");
    const order = await loadOwnOrder(req);
    const ok = req.body?.result !== "fail";
    const transId = req.body?.transId || `MOCK-${order.id}-${Date.now()}`;
    const r = await processPaymentResult({ provider: "mock", orderId: order.id, transId, amount: order.total, resultCode: ok ? 1 : -1, raw: req.body });
    res.json({ ...r, transId });
  }));
  app.post("/dev/run-jobs", wrap(async (_req, res) => { await runJobs(); res.json({ ok: true }); }));
}

app.use((_req, _res, next) => next(new AppError(404, "NOT_FOUND", "Không tìm thấy")));
app.use((err, _req, res, _next) => {
  if (!(err instanceof AppError)) console.error(err);
  const status = err.status || 500;
  res.status(status).json({ code: err.code || "INTERNAL", message: status === 500 ? "Lỗi hệ thống, vui lòng thử lại" : err.message, ...(err.extra || {}) });
});

// Tự tạo bảng khi khởi động; seed menu mẫu nếu DB trống (SEED_ON_EMPTY=false để tắt)
const sqlDir = path.join(path.dirname(fileURLToPath(import.meta.url)), "sql");
await q(fs.readFileSync(path.join(sqlDir, "schema.sql"), "utf8"));
if (process.env.SEED_ON_EMPTY !== "false" && (await q("SELECT count(*)::int n FROM menu_items")).rows[0].n === 0)
  await q(fs.readFileSync(path.join(sqlDir, "seed.sql"), "utf8"));
await syncStaffWhitelist();
setInterval(() => runJobs().catch((e) => console.error("job", e)), 60_000);
app.listen(config.port, () => console.log(`API :${config.port} env=${config.appEnv} payment=${config.paymentMode} auth=${config.authMode}`));
