import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { pool } from "../db.js";

const dir = path.dirname(fileURLToPath(import.meta.url));
const run = async (f) => pool.query(fs.readFileSync(path.join(dir, "..", "sql", f), "utf8"));

await run("schema.sql");
if (!process.argv.includes("--no-seed")) await run("seed.sql");
console.log("DB ready");
await pool.end();
