// Kiểm thử tự động TC-01..TC-12 (PRD §12) ở tầng API.
// Yêu cầu server chạy với APP_ENV=testing AUTH_MODE=dev PAYMENT_MODE=mock STAFF_ZALO_IDS=staff-1
// Chạy: BASE_URL=http://localhost:8080 npm run test:e2e
const BASE = process.env.BASE_URL || "http://localhost:8080";
let pass = 0, fail = 0;
const call = async (method, path, body, token) => {
  const res = await fetch(BASE + path, { method, headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: res.status, body: await res.json().catch(() => null) };
};
const check = (id, name, cond, info) => { cond ? pass++ : fail++; console.log(`${cond ? "PASS" : "FAIL"}  ${id} ${name}${cond ? "" : "  → " + JSON.stringify(info)}`); };
const loginAs = async (id, name) => (await call("POST", "/auth/login", { devUserId: id, name })).body.token;
const firstFreeSlot = async () => (await call("GET", "/slots/today")).body.find((s) => !s.disabled);

// Đặt giờ 09:00 ngày thứ Hai gần nhất để kịch bản chạy được mọi lúc
const monday = (() => { const d = new Date(); d.setUTCDate(d.getUTCDate() + ((8 - d.getUTCDay()) % 7 || 7)); return d.toISOString().slice(0, 10); })();
await call("POST", "/dev/clock", { time: "09:00", date: monday });

const linh = await loginAs("cust-linh", "Linh");
const minh = await loginAs("cust-minh", "Minh");
const staff = await loginAs("staff-1", "Quản lý");

// TC-01
const menu = (await call("GET", "/menu/today")).body;
const soldOut = menu.items.find((i) => i.soldOut);
check("TC-01", "Xem menu", menu.open && menu.items.length >= 10 && menu.items.every((i) => i.imageUrl && i.price > 0) && !!soldOut, menu);

// TC-02 (tính ở server)
const i45 = menu.items.find((i) => i.price === 45000 && i.portionsLeft >= 2), i50 = menu.items.find((i) => i.price === 50000 && !i.soldOut);
const slot = await firstFreeSlot();
const o2 = await call("POST", "/orders", { items: [{ menuItemId: i45.id, quantity: 2, expectedPrice: 45000 }, { menuItemId: i50.id, quantity: 1, expectedPrice: 50000 }], slotId: slot.id }, linh);
check("TC-02", "Tổng tiền 140.000đ", o2.status === 201 && o2.body.total === 140000, o2);

// TC-03
const o3 = await call("POST", "/orders", { items: [{ menuItemId: i45.id, quantity: 1 }] }, linh);
check("TC-03", "Bắt buộc chọn slot", o3.status === 400 && o3.body.code === "SLOT_REQUIRED", o3);

// TC-04
const pay = await call("POST", `/orders/${o2.body.id}/pay`, {}, linh);
const mp = await call("POST", `/dev/mock-pay/${o2.body.id}`, { result: "success" }, linh);
const r4 = await call("GET", `/orders/${o2.body.id}`, null, linh);
check("TC-04", "Thanh toán thành công → Paid + mã 4 số", pay.status === 200 && r4.body.status === "paid" && /^\d{4}$/.test(r4.body.code), { pay, mp, r4 });

// TC-11 (replay callback cùng transId)
const dup = await call("POST", `/dev/mock-pay/${o2.body.id}`, { result: "success", transId: mp.body.transId }, linh);
const mine = (await call("GET", "/orders/mine", null, linh)).body;
check("TC-11", "Callback lặp → 1 đơn, 1 payment", dup.body.duplicate === true && mine.filter((o) => o.id === o2.body.id && o.status === "paid").length === 1, { dup, mine });

// TC-05 (thất bại → vẫn pending, hết 10 phút → nhả hàng)
const stockBefore = (await call("GET", "/menu/today")).body.items.find((i) => i.id === i50.id).portionsLeft;
const o5 = await call("POST", "/orders", { items: [{ menuItemId: i50.id, quantity: 1 }], slotId: slot.id }, minh);
await call("POST", `/dev/mock-pay/${o5.body.id}`, { result: "fail" }, minh);
const r5 = (await call("GET", `/orders/${o5.body.id}`, null, minh)).body;
const retry = await call("POST", `/orders/${o5.body.id}/pay`, {}, minh);
await call("POST", "/dev/clock", { time: "09:11", date: monday });
await call("POST", "/dev/run-jobs");
const stockAfter = (await call("GET", "/menu/today")).body.items.find((i) => i.id === i50.id).portionsLeft;
const r5b = (await call("GET", `/orders/${o5.body.id}`, null, minh)).body;
check("TC-05", "Thất bại → Pending, retry được, nhả hàng sau 10'", r5.status === "pending_payment" && retry.status === 200 && r5b.status === "expired" && stockAfter === stockBefore, { r5: r5.status, retry: retry.status, r5b: r5b.status, stockBefore, stockAfter });

// TC-06 (tranh phần cuối) — đặt lại 1 phần cho món test để script chạy lặp được
const lastId = (await call("GET", "/menu/today")).body.items.find((i) => i.name === "Cơm cá kho tộ")?.id || 8;
await call("PUT", `/store/menu-items/${lastId}/stock`, { portionsLeft: 1, soldOut: false }, staff);
const last = { id: lastId };
const [a, b] = await Promise.all([
  call("POST", "/orders", { items: [{ menuItemId: last.id, quantity: 1 }], slotId: slot.id }, linh),
  call("POST", "/orders", { items: [{ menuItemId: last.id, quantity: 1 }], slotId: slot.id }, minh),
]);
const ok = [a, b].filter((x) => x.status === 201), blocked = [a, b].filter((x) => x.body?.code === "OUT_OF_STOCK");
check("TC-06", "Phần cuối: 1 thành công, 1 bị chặn", ok.length === 1 && blocked.length === 1, { a: a.status, b: b.status });
if (ok[0]) await call("POST", `/dev/mock-pay/${ok[0].body.id}`, { result: "success" }, ok[0] === a ? linh : minh);

// TC-08 / TC-09
const board = (await call("GET", "/store/orders", null, staff)).body;
const prep = board.prepSummary?.find((p) => p.menu_item_id === i45.id);
check("TC-08", "Board thấy đơn Paid + prep summary", board.orders?.some((o) => o.id === o2.body.id) && prep?.quantity >= 2 && !board.orders.some((o) => o.status === "pending_payment"), board);
const denied = await call("GET", "/store/orders", null, linh);
check("TC-09", "Khách không vào được board", denied.status === 403, denied);

// TC-10
const s1 = await call("PATCH", `/store/orders/${o2.body.id}/status`, { to: "preparing" }, staff);
const back = await call("PATCH", `/store/orders/${o2.body.id}/status`, { to: "paid" }, staff);
const s2 = await call("PATCH", `/store/orders/${o2.body.id}/status`, { to: "ready" }, staff);
const wrong = await call("PATCH", `/store/orders/${o2.body.id}/status`, { to: "picked_up", code: "0000" }, staff);
const s3 = await call("PATCH", `/store/orders/${o2.body.id}/status`, { to: "picked_up", code: r4.body.code }, staff);
const seen = (await call("GET", `/orders/${o2.body.id}`, null, linh)).body.status;
check("TC-10", "Status flow + chặn lùi + sai mã", s1.status === 200 && back.status === 409 && s2.status === 200 && wrong.status === 422 && s3.status === 200 && seen === "picked_up", { s1: s1.status, back: back.status, s2: s2.status, wrong: wrong.status, s3: s3.status, seen });

// TC-12
const reopen = (await call("GET", "/orders/mine", null, linh)).body;
check("TC-12", "Mở lại app vẫn thấy đơn", reopen.some((o) => o.id === o2.body.id), reopen);

// TC-07
await call("POST", "/dev/clock", { time: "10:31", date: monday });
const m7 = (await call("GET", "/menu/today")).body;
const o7 = await call("POST", "/orders", { items: [{ menuItemId: i45.id, quantity: 1 }], slotId: slot.id }, linh);
check("TC-07", "Sau 10:30 chỉ xem", !m7.open && m7.message === "Đã hết giờ đặt hôm nay" && o7.body.code === "ORDERING_CLOSED", { m7: m7.message, o7 });

await call("POST", "/dev/clock", { reset: true });
console.log(`\n${pass}/${pass + fail} passed`);
process.exit(fail ? 1 : 0);
