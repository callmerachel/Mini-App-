import crypto from "node:crypto";
import jwt from "jsonwebtoken";
import { config } from "./config.js";
import { q } from "./db.js";
import { AppError } from "./domain.js";

// Decode Zalo access token server-to-server (Best practice 4.5.1 — không decode ở Mini App)
async function zaloProfile(accessToken) {
  const proof = crypto.createHmac("sha256", config.zaloAppSecret).update(accessToken).digest("hex");
  const res = await fetch("https://graph.zalo.me/v2.0/me?fields=id,name", {
    headers: { access_token: accessToken, appsecret_proof: proof },
  });
  const data = await res.json();
  if (!data?.id) throw new AppError(401, "ZALO_AUTH_FAILED", data?.message || "Không xác thực được tài khoản Zalo");
  return { id: String(data.id), name: data.name || null };
}

export async function login(body) {
  let profile;
  if (config.authMode === "dev" && body?.devUserId) {
    profile = { id: String(body.devUserId), name: body.name || null };
  } else {
    if (!body?.accessToken) throw new AppError(400, "TOKEN_REQUIRED", "Thiếu access token");
    profile = await zaloProfile(body.accessToken);
  }
  // Tên hiển thị: ưu tiên tên từ getUserInfo (client, chỉ để hiển thị), fallback tên Graph API
  const name = (body?.name || profile.name || "").toString().slice(0, 60) || null;
  await q(`INSERT INTO customers (zalo_id, display_name) VALUES ($1,$2)
           ON CONFLICT (zalo_id) DO UPDATE SET display_name = COALESCE(EXCLUDED.display_name, customers.display_name)`, [profile.id, name]);
  const role = await roleOf(profile.id);
  const token = jwt.sign({ sub: profile.id, name }, config.jwtSecret, { expiresIn: "7d" });
  return { token, user: { id: profile.id, name, role } };
}

export async function roleOf(zaloId) {
  const r = await q(`SELECT role FROM staff WHERE zalo_id=$1`, [zaloId]);
  return r.rows[0]?.role || "customer";
}

export function requireUser(req, _res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return next(new AppError(401, "UNAUTHORIZED", "Chưa đăng nhập"));
  try { req.user = jwt.verify(token, config.jwtSecret); next(); }
  catch { next(new AppError(401, "UNAUTHORIZED", "Phiên đăng nhập hết hạn")); }
}

// Role check phía server (NFR Security) — whitelist Zalo ID
export const requireStaff = (roles = ["manager", "kitchen"]) => async (req, _res, next) => {
  try {
    const role = await roleOf(req.user.sub);
    if (!roles.includes(role)) return next(new AppError(403, "FORBIDDEN", "Bạn không có quyền truy cập khu vực của quán"));
    req.user.role = role; next();
  } catch (e) { next(e); }
};

export async function syncStaffWhitelist() {
  for (const id of config.staffZaloIds) {
    await q(`INSERT INTO staff (zalo_id, role) VALUES ($1,'manager') ON CONFLICT (zalo_id) DO NOTHING`, [id]);
  }
}
