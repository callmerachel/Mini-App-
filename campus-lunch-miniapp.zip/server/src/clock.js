// Đồng hồ GMT+7. Bản testing có thể dời giờ (TC-07: "set clock to 10:31") qua POST /dev/clock.
let offsetMs = 0;
const VN_OFFSET = 7 * 60 * 60 * 1000;

export const clock = {
  now: () => new Date(Date.now() + offsetMs),
  setVnTime(hhmm, dateStr) {
    const cur = vn();
    const date = dateStr || cur.date;
    const target = Date.parse(`${date}T${hhmm}:00+07:00`);
    offsetMs = target - Date.now();
  },
  reset() { offsetMs = 0; },
  offsetMs: () => offsetMs,
};

// Trả về ngày/giờ theo giờ Việt Nam
export function vn(d = clock.now()) {
  const t = new Date(d.getTime() + VN_OFFSET);
  const date = t.toISOString().slice(0, 10);
  const minutes = t.getUTCHours() * 60 + t.getUTCMinutes();
  return { date, minutes, weekday: t.getUTCDay(), hhmm: t.toISOString().slice(11, 16) };
}

export const toMin = (hhmm) => { const [h, m] = hhmm.split(":").map(Number); return h * 60 + m; };
export const toHHMM = (min) => `${String(Math.floor(min / 60)).padStart(2, "0")}:${String(min % 60).padStart(2, "0")}`;
