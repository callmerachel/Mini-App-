# Cơm Trưa Đặt Trước — Zalo Mini App (v0.1 Testing)

Bản triển khai PRD "Campus Lunch Pre-Order". Gồm 2 phần:

| Thư mục | Nội dung | Chạy ở đâu |
|---|---|---|
| `miniapp/` | Mini App React + ZaUI (template chính thức `zmp-blank-templates/vite-5-javascript`). 5 màn: Món ăn (S1), Giỏ & Thanh toán (S2), Kết quả đơn (S3), Đơn của tôi, Bảng đơn quán (S4) | Zalo (deploy bằng `zmp-cli`) |
| `server/` | REST API Node.js + PostgreSQL. 9 entity, BR-01→BR-10, giữ món 10 phút, callback idempotent, role check phía server | Host HTTPS bất kỳ (Render/Railway/VPS) |

Trạng thái kiểm thử: `server` pass **12/12** TC-01→TC-12 (tầng API, `npm run test:e2e`). Luồng UI khách → thanh toán giả lập → mã đơn → bảng đơn quán đã chạy thử trên trình duyệt. **Chưa chạy trên Zalo thật** — cần Mini App ID của bạn.

---

## A. Chạy thử trên máy (≈10 phút)

Yêu cầu: Node.js ≥ 20, Docker (hoặc PostgreSQL sẵn có).

```bash
# 1) Backend + DB
docker compose up -d            # API ở http://localhost:8080 (đăng nhập giả lập, thanh toán giả lập)
curl localhost:8080/health

# 2) Mini App
cd miniapp
cp .env.example .env            # sửa: VITE_API_URL=http://localhost:8080 ; VITE_AUTH_MODE=dev
npm install
npm start                       # mở trình duyệt; thêm ?as=staff-1 vào URL để vào vai nhân viên quán

# 3) Test tự động 12 TC
cd ../server && npm install && BASE_URL=http://localhost:8080 npm run test:e2e
```

Lưu ý: icon ZaUI có thể không hiện khi chạy ngoài Zalo (font bị chặn CORS ở localhost) — trong Zalo hiển thị bình thường.

---

## B. Deploy backend (HTTPS bắt buộc)

1. Tạo PostgreSQL miễn phí (Neon/Supabase) → copy `DATABASE_URL`.
2. Render → New → Blueprint → chọn repo chứa thư mục này (`render.yaml` có sẵn). Hoặc dùng `server/Dockerfile` trên host bất kỳ.
3. Điền env theo `server/.env.example`. Bảng + menu mẫu tự tạo khi khởi động lần đầu.
4. Kiểm tra: `https://<api-domain>/health` trả `{"ok":true}`.

CORS đã trả đúng 1 origin `https://h5.zdn.vn` cho cả OPTIONS (docs mục 4.3.1).
Render gói free "ngủ" sau 15 phút → lần mở đầu chậm: chấp nhận cho testing, **không đạt NFR ≤ 2s** cho production.

---

## C. Deploy Mini App lên Zalo

```bash
cd miniapp
# .env:  APP_ID=<Mini App ID>   VITE_API_URL=https://<api-domain>   VITE_AUTH_MODE=zalo   VITE_OA_ID=<OA ID, tuỳ chọn>
npm run login          # quét QR bằng Zalo (tài khoản admin của Mini App)
npm run start:device   # chạy trên điện thoại thật: test getAccessToken, Checkout
npm run deploy         # chọn "Testing" → nhập mô tả phiên bản
```

Sau khi deploy: vào tab **Đơn** trên Mini App → cuối trang có "Mã tài khoản" → thêm vào `STAFF_ZALO_IDS` của backend → restart → tab **Quán** xuất hiện.

---

## D. Ba cấu hình môi trường

| Mục đích | `APP_ENV` | `AUTH_MODE` | `PAYMENT_MODE` | Frontend `VITE_AUTH_MODE` |
|---|---|---|---|---|
| Dev trên trình duyệt | testing | dev | mock | dev |
| UAT nội bộ trong Zalo (12 TC) | testing | zalo | mock hoặc checkout | zalo |
| **Bản gửi xét duyệt / Live** | **production** | **zalo** | **checkout** | **zalo** |

`APP_ENV=production` tắt toàn bộ `/dev/*` (đổi giờ, giả lập thanh toán). Mini App có thanh toán **bắt buộc** tích hợp Checkout SDK → không gửi duyệt bản `mock`.

### Bật Checkout SDK
1. Trang quản lý Mini App → Checkout SDK → đăng ký, lấy **private key**, chọn phương thức sandbox.
2. **Notify URL** = `https://<api-domain>/payments/callback`.
3. Backend env: `PAYMENT_MODE=checkout`, `CHECKOUT_PRIVATE_KEY`, `CHECKOUT_METHOD`.
4. **[Cần xác nhận với docs Checkout SDK trước khi go-live]** — 3 điểm viết theo hiểu biết, chưa đối chiếu nguồn chính thức:
   - MAC tạo đơn: HMAC-SHA256(key, các field `amount, desc, extradata, item, method` sắp a→z, nối `k=v&…`) — `server/src/domain.js › buildCheckoutParams`
   - MAC callback: chuỗi `appId, amount, description, orderId, message, resultCode, transId` — `verifyCallbackMac`
   - Response callback `{ returnCode: 1, returnMessage }` và tên method (vd `ZALOPAY_SANDBOX`)

---

## E. Kịch bản UAT (PRD §12) — thao tác trên app

| TC | Thao tác | Kỳ vọng |
|---|---|---|
| 01 | Mở app | 10 món có ảnh/mô tả/giá; "Bánh canh cua" = Hết món, nút khoá |
| 02 | 2 × Cơm tấm sườn + 1 × Bún bò | Tổng 140.000đ |
| 03 | Bấm Thanh toán khi chưa chọn giờ | Báo "Vui lòng chọn giờ nhận món" |
| 04 | Chọn giờ → Thanh toán → thành công | Màn mã 4 số + QR, trạng thái Đã thanh toán |
| 05 | Thanh toán → thất bại | Màn "Thanh toán lại"; sau 10 phút đơn Hết hạn, trả lại phần |
| 06 | 2 máy cùng đặt "Cơm cá kho tộ" (1 phần) | 1 máy thành công, máy kia báo "Hết món", không bị trừ tiền |
| 07 | Sau 10:30 (bản testing: `POST /dev/clock {"time":"10:31"}`) | Menu chỉ xem, banner "Đã hết giờ đặt hôm nay" |
| 08 | Nhân viên mở tab Quán | Đơn mới hiện ≤ 15s, nhóm theo khung giờ, có tổng món cần làm |
| 09 | Khách mở `/store` | "Bạn không có quyền truy cập" (server trả 403) |
| 10 | Bắt đầu làm → Báo món xong → Giao món (nhập sai rồi đúng mã) | Khách thấy trạng thái ≤ 15s; sai mã bị chặn |
| 11 | Gửi lặp callback | Vẫn 1 đơn, 1 payment (tự động trong `test:e2e`) |
| 12 | Trả tiền xong đóng app, mở lại | Đơn nằm trong "Đơn của tôi" |

Exit criteria: 12/12 pass · 0 bug P0 · ≥ 95% thanh toán thành công / 20 lần sandbox.

---

## F. Phạm vi v0.1 và việc còn lại

Đã có: toàn bộ Release 1 (US-01→US-08) + một phần US-09 (chỉnh số phần, bật/tắt Hết món) + nút theo dõi OA (US-10, chỉ phần follow).

Chưa có:
- Tin nhắn OA xác nhận/báo món xong (US-10) — cần API OA gọi từ server.
- Khách tự huỷ (US-11) — v0.1 quán huỷ + hoàn tiền thủ công (BR-08).
- Job đối soát Checkout mỗi 5 phút (PRD §13.3) — có chỗ TODO trong `runJobs()`.
- Thêm/sửa món, upload ảnh (US-09 đầy đủ) — hiện sửa trực tiếp bảng `menu_items`.

Ảnh món mẫu là SVG minh hoạ do server sinh ra. Thay bằng ảnh thật (≤ 150 KB) qua cột `menu_items.image_url`.
