import React, { createContext, useCallback, useContext, useEffect, useState } from "react";
import { getAccessToken, getUserInfo } from "zmp-sdk/apis";
import { Api, setToken } from "../lib/api";
import { storage } from "../lib/storage";

const SessionCtx = createContext(null);
const AUTH_MODE = import.meta.env.VITE_AUTH_MODE || "zalo";

// Đăng nhập bằng tài khoản Zalo (docs 4.5.1): getAccessToken → server decode → JWT của hệ thống quán
async function signIn() {
  if (AUTH_MODE === "dev") {
    const params = new URLSearchParams(window.location.search);
    const devUserId = params.get("as") || storage.get("dev_user") || `dev-${Math.random().toString(36).slice(2, 8)}`;
    storage.set("dev_user", devUserId);
    return Api.login({ devUserId, name: devUserId.startsWith("staff") ? "Nhân viên" : "Khách thử nghiệm" });
  }
  const accessToken = await getAccessToken();
  let name = null;
  try {
    // Không tự bật popup xin quyền khi vừa mở app; tên chỉ dùng để hiển thị, thiếu thì dùng "Khách + mã đơn"
    const { userInfo } = await getUserInfo({ autoRequestPermission: false });
    name = userInfo?.name || null;
  } catch { /* người dùng chưa cấp quyền tên */ }
  return Api.login({ accessToken, name });
}

export function SessionProvider({ children }) {
  const [state, setState] = useState({ status: "loading", user: null, error: null });

  const start = useCallback(async () => {
    setState((s) => ({ ...s, status: "loading", error: null }));
    try {
      const { token, user } = await signIn();
      setToken(token);
      setState({ status: "ready", user, error: null });
    } catch (e) {
      setState({ status: "error", user: null, error: e?.message || "Không đăng nhập được" });
    }
  }, []);

  useEffect(() => { start(); }, [start]);

  return <SessionCtx.Provider value={{ ...state, retry: start, isStaff: ["manager", "kitchen"].includes(state.user?.role) }}>{children}</SessionCtx.Provider>;
}

export const useSession = () => useContext(SessionCtx);
