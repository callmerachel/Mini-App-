import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { storage } from "../lib/storage";
import { todayVN } from "../lib/format";

// US-02: giỏ hàng giữ lại khi rời/mở lại app trong cùng ngày
const CartCtx = createContext(null);
const KEY = "cart_v1";

function load() {
  const saved = storage.get(KEY);
  return saved && saved.date === todayVN() ? saved : { date: todayVN(), lines: {}, slotId: null };
}

export function CartProvider({ children }) {
  const [cart, setCart] = useState(load);
  useEffect(() => { storage.set(KEY, cart); }, [cart]);

  const api = useMemo(() => {
    const update = (fn) => setCart((c) => ({ ...fn(c), date: todayVN() }));
    return {
      cart,
      lines: Object.values(cart.lines),
      count: Object.values(cart.lines).reduce((s, l) => s + l.quantity, 0),
      total: Object.values(cart.lines).reduce((s, l) => s + l.quantity * l.price, 0),
      add: (item) => update((c) => ({ ...c, lines: { ...c.lines, [item.id]: { id: item.id, name: item.name, price: item.price, imageUrl: item.imageUrl, quantity: 1, note: "" } } })),
      setQty: (id, quantity) => update((c) => {
        const lines = { ...c.lines };
        if (quantity <= 0) delete lines[id]; else lines[id] = { ...lines[id], quantity };
        return { ...c, lines };
      }),
      setNote: (id, note) => update((c) => ({ ...c, lines: { ...c.lines, [id]: { ...c.lines[id], note: note.slice(0, 100) } } })),
      setPrice: (id, price) => update((c) => (c.lines[id] ? { ...c, lines: { ...c.lines, [id]: { ...c.lines[id], price } } } : c)),
      setSlot: (slotId) => update((c) => ({ ...c, slotId })),
      clear: () => setCart({ date: todayVN(), lines: {}, slotId: null }),
    };
  }, [cart]);

  return <CartCtx.Provider value={api}>{children}</CartCtx.Provider>;
}

export const useCart = () => useContext(CartCtx);
