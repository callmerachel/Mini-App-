import React from "react";
import { getSystemInfo } from "zmp-sdk";
import { AnimationRoutes, App, Route, SnackbarProvider, ZMPRouter, BottomNavigation, Icon, useLocation, Box, Button, Text, Spinner } from "zmp-ui";

import { SessionProvider, useSession } from "../state/session";
import { CartProvider, useCart } from "../state/cart";
import MenuPage from "../pages/menu";
import CartPage from "../pages/cart";
import ResultPage from "../pages/result";
import OrdersPage from "../pages/orders";
import StorePage from "../pages/store";

// Bottom bar 3–4 tab, label ≤ 6 ký tự (Design Guidelines 3.3.1)
function TabBar() {
  const { pathname } = useLocation();
  const { isStaff } = useSession();
  const { count } = useCart();
  const tabs = ["/", "/cart", "/orders", "/store"];
  if (!tabs.includes(pathname)) return null;
  return (
    <BottomNavigation fixed activeKey={pathname}>
      <BottomNavigation.Item key="/" label="Món ăn" linkTo="/" icon={<Icon icon="zi-home" />} />
      <BottomNavigation.Item key="/cart" label={count ? `Giỏ (${count})` : "Giỏ"} linkTo="/cart" icon={<Icon icon="zi-note" />} />
      <BottomNavigation.Item key="/orders" label="Đơn" linkTo="/orders" icon={<Icon icon="zi-list-1" />} />
      {isStaff && <BottomNavigation.Item key="/store" label="Quán" linkTo="/store" icon={<Icon icon="zi-admin" />} />}
    </BottomNavigation>
  );
}

function Gate({ children }) {
  const { status, error, retry } = useSession();
  if (status === "loading")
    return <Box className="gate"><Spinner visible /><Text className="muted">Đang mở thực đơn…</Text></Box>;
  if (status === "error")
    return (
      <Box className="gate">
        <Text.Title size="small">Chưa kết nối được với quán</Text.Title>
        <Text className="muted center">{error}</Text>
        <Button onClick={retry}>Thử lại</Button>
      </Box>
    );
  return children;
}

const Layout = () => (
  <App theme={getSystemInfo().zaloTheme}>
    <SnackbarProvider>
      <SessionProvider>
        <CartProvider>
          <ZMPRouter>
            <Gate>
              <AnimationRoutes>
                <Route path="/" element={<MenuPage />} />
                <Route path="/cart" element={<CartPage />} />
                <Route path="/result/:id" element={<ResultPage />} />
                <Route path="/orders" element={<OrdersPage />} />
                <Route path="/store" element={<StorePage />} />
              </AnimationRoutes>
              <TabBar />
            </Gate>
          </ZMPRouter>
        </CartProvider>
      </SessionProvider>
    </SnackbarProvider>
  </App>
);
export default Layout;
