import React, { useState } from "react";
import { Box, Text } from "zmp-ui";
import { assetUrl } from "../lib/api";
import { STATUS, STEPS, STEP_LABEL } from "../lib/format";
import placeholder from "../static/dish-placeholder.svg";

// US-01: ảnh lỗi → placeholder, món vẫn đặt được. Ảnh lazy-load (NFR mạng yếu).
export function DishImage({ src, alt, className = "" }) {
  const [broken, setBroken] = useState(!src);
  return <img className={`dish-img ${className}`} src={broken ? placeholder : assetUrl(src)} alt={alt} loading="lazy" onError={() => setBroken(true)} />;
}

export function Stepper({ value, max, onChange, disabled }) {
  return (
    <div className="stepper" aria-label="Số lượng">
      <button type="button" aria-label="Giảm" onClick={() => onChange(value - 1)} disabled={disabled}><span aria-hidden="true">−</span></button>
      <span className="stepper-value">{value}</span>
      <button type="button" aria-label="Tăng" onClick={() => onChange(value + 1)} disabled={disabled || value >= max}><span aria-hidden="true">+</span></button>
    </div>
  );
}

export function StatusBadge({ status }) {
  const s = STATUS[status] || { label: status, tone: "neutral" };
  return <span className={`badge badge-${s.tone}`}>{s.label}</span>;
}

export function StatusSteps({ status }) {
  const idx = STEPS.indexOf(status);
  return (
    <ol className="steps">
      {STEPS.map((s, i) => (
        <li key={s} className={i <= idx ? "done" : ""} aria-current={i === idx ? "step" : undefined}>
          <span className="dot" />
          <span className="lbl">{STEP_LABEL[s]}</span>
        </li>
      ))}
    </ol>
  );
}

export function Banner({ tone = "info", children }) {
  return <Box className={`banner banner-${tone}`}><Text size="small">{children}</Text></Box>;
}

export function Empty({ title, hint, action }) {
  return (
    <Box className="empty">
      <Text.Title size="small">{title}</Text.Title>
      {hint && <Text className="muted center">{hint}</Text>}
      {action}
    </Box>
  );
}
