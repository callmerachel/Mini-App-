import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Box, Button, Header, Page, Text, useNavigate } from "zmp-ui";
import { Api } from "../lib/api";
import { vnd } from "../lib/format";
import { usePoll } from "../lib/use-poll";
import { useCart } from "../state/cart";
import { Banner, DishImage, Empty, Stepper } from "../components/ui";

// S1 E-menu — states: loading, normal, sold out, after cutoff, closed day
export default function MenuPage() {
  const nav = useNavigate();
  const cart = useCart();
  const [menu, setMenu] = useState(null);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    try { setMenu(await Api.menu()); setError(null); } catch (e) { setError(e.message); }
  }, []);
  useEffect(() => { load(); }, [load]);
  usePoll(load, 30000); // cập nhật số phần còn lại

  const groups = useMemo(() => {
    const g = new Map();
    (menu?.items || []).forEach((i) => { if (!g.has(i.category)) g.set(i.category, []); g.get(i.category).push(i); });
    return [...g.entries()];
  }, [menu]);

  const canOrder = menu?.open;

  return (
    <Page className="page with-tabbar">
      <Header title="Cơm Trưa Đặt Trước" showBackIcon={false} />
      {!menu && !error && <MenuSkeleton />}
      {error && <Empty title="Chưa tải được thực đơn" hint={error} action={<Button variant="secondary" onClick={load}>Tải lại</Button>} />}
      {menu && (
        <>
          <Box className="hero">
            <Text.Title size="large">Hôm nay ăn gì?</Text.Title>
            <Text className="muted">
              {canOrder ? `Đặt và trả trước ${menu.cutoff}, nhận món từ 11:00 không cần xếp hàng.` : " "}
            </Text>
          </Box>
          {!canOrder && <Banner tone={menu.reason === "closed_day" ? "neutral" : "warning"}>{menu.message}</Banner>}
          {menu.reason === "closed_day" ? (
            <Empty title="Hôm nay quán nghỉ" hint="Hẹn bạn vào ngày làm việc tiếp theo." />
          ) : (
            groups.map(([cat, items]) => (
              <section key={cat} className="menu-group">
                <Text.Title size="small" className="group-title">{cat}</Text.Title>
                {items.map((item) => (
                  <DishRow key={item.id} item={item} canOrder={canOrder} max={Math.min(menu.maxQtyPerDish, item.portionsLeft)} />
                ))}
              </section>
            ))
          )}
        </>
      )}
      {cart.count > 0 && canOrder && (
        <div className="cart-bar">
          <div>
            <Text size="xSmall" className="muted">{cart.count} phần</Text>
            <Text.Title size="small">{vnd(cart.total)}</Text.Title>
          </div>
          <Button onClick={() => nav("/cart")}>Xem giỏ hàng</Button>
        </div>
      )}
    </Page>
  );
}

function DishRow({ item, canOrder, max }) {
  const cart = useCart();
  const line = cart.cart.lines[item.id];
  const low = !item.soldOut && item.portionsLeft <= 5;
  return (
    <div className={`dish ${item.soldOut ? "is-soldout" : ""}`}>
      <DishImage src={item.imageUrl} alt={item.name} />
      <div className="dish-body">
        <Text.Title size="small" className="dish-name">{item.name}</Text.Title>
        <Text size="small" className="muted clamp-2">{item.description}</Text>
        <div className="dish-foot">
          <div>
            <Text className="price">{vnd(item.price)}</Text>
            <Text size="xxSmall" className={item.soldOut ? "text-danger" : low ? "text-warning" : "muted"}>
              {item.soldOut ? "Hết món" : `Còn ${item.portionsLeft} phần`}
            </Text>
          </div>
          {line ? (
            <Stepper value={line.quantity} max={max} disabled={!canOrder} onChange={(q) => cart.setQty(item.id, Math.min(q, max))} />
          ) : (
            <Button size="small" variant="secondary" disabled={!canOrder || item.soldOut} onClick={() => cart.add(item)}>
              {item.soldOut ? "Hết món" : "Thêm"}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

function MenuSkeleton() {
  return (
    <Box className="menu-group" aria-busy="true">
      {[0, 1, 2, 3].map((i) => (
        <div className="dish" key={i}><div className="dish-img skeleton" /><div className="dish-body"><div className="skeleton line" /><div className="skeleton line short" /></div></div>
      ))}
    </Box>
  );
}
