import React, { useCallback, useEffect, useRef, useState } from "react";
import { Box, Button, Header, Page, Spinner, Text, useNavigate, useParams, useSearchParams, useSnackbar } from "zmp-ui";
import { followOA } from "zmp-sdk/apis";
import QRCode from "qrcode";
import { Api } from "../lib/api";
import { vnd } from "../lib/format";
import { startPayment } from "../lib/payment";
import { usePoll } from "../lib/use-poll";
import { useCart } from "../state/cart";
import { Banner, Empty, StatusBadge, StatusSteps } from "../components/ui";

const OA_ID = import.meta.env.VITE_OA_ID;

// S3 Order Result — states: Paid, Preparing, Ready, Picked up, payment failed
export default function ResultPage() {
  const { id } = useParams();
  const [params] = useSearchParams();
  const nav = useNavigate();
  const cart = useCart();
  const { openSnackbar } = useSnackbar();
  const [order, setOrder] = useState(null);
  const [error, setError] = useState(null);
  const [qr, setQr] = useState(null);
  const [retrying, setRetrying] = useState(false);
  const [confirming, setConfirming] = useState(params.get("justPaid") === "1");
  const startedAt = useRef(Date.now());

  const load = useCallback(async () => {
    try {
      const o = await Api.order(id);
      setOrder(o); setError(null);
      if (o.status !== "pending_payment" || Date.now() - startedAt.current > 20000) setConfirming(false);
      if (o.status === "paid") cart.clear();
    } catch (e) { setError(e.message); setConfirming(false); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);
  useEffect(() => { load(); }, [load]);
  usePoll(load, confirming ? 2000 : 15000, [confirming]); // chờ callback thanh toán nhanh hơn; sau đó 15s (US-06 ≤30s)

  useEffect(() => {
    if (order?.code) QRCode.toDataURL(order.code, { margin: 1, width: 240 }).then(setQr).catch(() => setQr(null));
  }, [order?.code]);

  async function retryPay() {
    setRetrying(true);
    try {
      const { mode } = await startPayment(order.id);
      if (mode === "mock") { await Api.mockPay(order.id, "success"); }
      startedAt.current = Date.now(); setConfirming(true); load();
    } catch (e) { openSnackbar({ text: e.message, type: "error" }); load(); }
    finally { setRetrying(false); }
  }

  async function onFollow() {
    try { await followOA({ id: OA_ID }); openSnackbar({ text: "Đã theo dõi quán", type: "success" }); }
    catch { /* người dùng đóng popup */ }
  }

  const header = <Header title="Đơn của bạn" onBackClick={() => nav("/orders", { replace: true })} />;
  if (error) return <Page className="page">{header}<Empty title="Không mở được đơn" hint={error} action={<Button variant="secondary" onClick={load}>Thử lại</Button>} /></Page>;
  if (!order || (confirming && order.status === "pending_payment"))
    return <Page className="page">{header}<Box className="gate"><Spinner visible /><Text className="muted">Đang xác nhận thanh toán với quán…</Text></Box></Page>;

  const paidLike = ["paid", "preparing", "ready", "picked_up", "no_show"].includes(order.status);

  return (
    <Page className="page">
      {header}
      {order.status === "pending_payment" && (
        <Banner tone="warning">Thanh toán chưa thành công. Món được giữ đến {new Date(order.holdExpiresAt).toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })} — bạn có thể thanh toán lại.</Banner>
      )}
      {order.status === "expired" && <Banner tone="neutral">Đơn đã hết thời gian giữ món và chưa bị trừ tiền. Hãy đặt lại từ thực đơn.</Banner>}
      {order.status === "cancelled_by_store" && <Banner tone="danger">Quán đã huỷ đơn{order.cancelReason ? `: ${order.cancelReason}` : ""}. Quán sẽ hoàn tiền cho bạn.</Banner>}
      {order.status === "ready" && <Banner tone="success">Món đã sẵn sàng. Đưa mã này cho quầy để nhận.</Banner>}

      {paidLike && (
        <div className="ticket">
          <Text size="xSmall" className="ticket-label">Mã nhận món</Text>
          <div className="ticket-code" aria-label={`Mã ${order.code.split("").join(" ")}`}>{order.code}</div>
          {qr && <img className="ticket-qr" src={qr} alt="QR mã nhận món" />}
          <div className="ticket-cut" aria-hidden="true" />
          <div className="ticket-meta">
            <div><Text size="xxSmall" className="muted">Giờ nhận</Text><Text.Title size="small">{order.slot.start}–{order.slot.end}</Text.Title></div>
            <div><Text size="xxSmall" className="muted">Người nhận</Text><Text.Title size="small">{order.customerName}</Text.Title></div>
          </div>
        </div>
      )}

      <Box className="section">
        <div className="row-between"><Text.Title size="small">Trạng thái</Text.Title><StatusBadge status={order.status} /></div>
        {paidLike && order.status !== "no_show" && <StatusSteps status={order.status} />}
      </Box>

      <Box className="section">
        {order.items.map((i) => (
          <div className="row-between item-line" key={i.menuItemId}>
            <div><Text>{i.quantity} × {i.name}</Text>{i.note && <Text size="xSmall" className="muted">“{i.note}”</Text>}</div>
            <Text>{vnd(i.lineTotal)}</Text>
          </div>
        ))}
        <div className="row-between total"><Text.Title size="small">{paidLike ? "Đã thanh toán" : "Tổng cộng"}</Text.Title><Text.Title size="small">{vnd(order.total)}</Text.Title></div>
      </Box>

      <Box className="actions">
        {order.status === "pending_payment" && <Button fullWidth loading={retrying} onClick={retryPay}>Thanh toán lại {vnd(order.total)}</Button>}
        {order.status === "expired" && <Button fullWidth onClick={() => nav("/", { replace: true })}>Đặt lại từ thực đơn</Button>}
        {paidLike && OA_ID && <Button fullWidth variant="secondary" onClick={onFollow}>Theo dõi quán để nhận tin báo món xong</Button>}
      </Box>
    </Page>
  );
}
