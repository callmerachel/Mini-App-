import React, { useCallback, useEffect, useState } from "react";
import { Box, Button, Header, Page, Text, useNavigate } from "zmp-ui";
import { Api } from "../lib/api";
import { vnd, todayVN } from "../lib/format";
import { usePoll } from "../lib/use-poll";
import { useSession } from "../state/session";
import { Empty, StatusBadge } from "../components/ui";

// "Đơn của tôi" (US-06, TC-12)
export default function OrdersPage() {
  const nav = useNavigate();
  const { user } = useSession();
  const [orders, setOrders] = useState(null);
  const [error, setError] = useState(null);
  const load = useCallback(async () => {
    try { setOrders(await Api.myOrders()); setError(null); } catch (e) { setError(e.message); }
  }, []);
  useEffect(() => { load(); }, [load]);
  usePoll(load, 15000);

  const today = todayVN();
  const sorted = (orders || []).slice().sort((a, b) => (b.day + b.id).localeCompare(a.day + a.id, undefined, { numeric: true }));

  return (
    <Page className="page with-tabbar">
      <Header title="Đơn của tôi" showBackIcon={false} />
      {error && <Empty title="Chưa tải được đơn" hint={error} action={<Button variant="secondary" onClick={load}>Tải lại</Button>} />}
      {orders && !orders.length && <Empty title="Bạn chưa có đơn nào" hint="Đặt trước để nhận món không cần xếp hàng." action={<Button onClick={() => nav("/")}>Đặt món</Button>} />}
      <Box className="list">
        {sorted.map((o) => (
          <button type="button" key={o.id} className="order-card" onClick={() => nav(`/result/${o.id}`)}>
            <div className="row-between">
              <Text.Title size="small">#{o.code} · {o.day === today ? "Hôm nay" : o.day.split("-").reverse().join("/")}</Text.Title>
              <StatusBadge status={o.status} />
            </div>
            <Text size="small" className="muted clamp-1">{o.items.map((i) => `${i.quantity} ${i.name}`).join(", ")}</Text>
            <div className="row-between"><Text size="small">Nhận {o.slot.start}</Text><Text size="small" className="price">{vnd(o.total)}</Text></div>
          </button>
        ))}
      </Box>
      {/* Quản lý quán cần ID này để thêm nhân viên vào whitelist (STAFF_ZALO_IDS) */}
      <Text size="xxSmall" className="muted center footnote">Mã tài khoản: {user?.id}</Text>
    </Page>
  );
}
