import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Box, Button, Header, Input, Modal, Page, Switch, Tabs, Text, useNavigate, useSnackbar } from "zmp-ui";
import { scanQRCode } from "zmp-sdk/apis";
import { Api } from "../lib/api";
import { vnd } from "../lib/format";
import { usePoll } from "../lib/use-poll";
import { useSession } from "../state/session";
import { Banner, Empty, StatusBadge, Stepper } from "../components/ui";

const NEXT = { paid: { to: "preparing", label: "Bắt đầu làm" }, preparing: { to: "ready", label: "Báo món xong" } };

// S4 Store Order Board — states: no orders, new order, wrong code, No-show
export default function StorePage() {
  const nav = useNavigate();
  const { isStaff, user } = useSession();
  const { openSnackbar } = useSnackbar();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [tab, setTab] = useState("orders");
  const [code, setCode] = useState("");
  const [handover, setHandover] = useState(null); // order chờ xác nhận giao
  const [cancelFor, setCancelFor] = useState(null);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(null);
  const seen = useRef(null);
  const [fresh, setFresh] = useState(new Set());

  const load = useCallback(async () => {
    try {
      const d = await Api.storeOrders();
      const ids = new Set(d.orders.map((o) => o.id));
      if (seen.current) setFresh(new Set([...ids].filter((i) => !seen.current.has(i))));
      seen.current = ids;
      setData(d); setError(null);
    } catch (e) { setError(e); }
  }, []);
  useEffect(() => { load(); }, [load]);
  usePoll(load, 15000); // US-07: đơn mới hiện ≤ 30s

  const bySlot = useMemo(() => {
    const g = new Map();
    (data?.orders || []).forEach((o) => { const k = `${o.slot.start}–${o.slot.end}`; if (!g.has(k)) g.set(k, []); g.get(k).push(o); });
    return [...g.entries()];
  }, [data]);

  if (!isStaff || error?.status === 403)
    return (
      <Page className="page">
        <Header title="Khu vực của quán" onBackClick={() => nav("/", { replace: true })} />
        <Empty title="Bạn không có quyền truy cập" hint={`Khu vực này chỉ dành cho nhân viên quán. Mã tài khoản của bạn: ${user?.id}`} />
      </Page>
    );

  async function move(order, to, extra) {
    setBusy(order.id);
    try { await Api.setStatus(order.id, to, extra); await load(); return true; }
    catch (e) { openSnackbar({ text: e.message, type: "error" }); return false; }
    finally { setBusy(null); }
  }

  function findByCode(c) {
    const o = data?.orders.find((x) => x.code === c.trim());
    if (!o) return openSnackbar({ text: "Sai mã đơn — không có đơn nào hôm nay với mã này", type: "error" });
    if (o.status !== "ready") return openSnackbar({ text: `Đơn #${o.code} đang ở trạng thái: ${o.status === "picked_up" ? "đã giao" : "chưa sẵn sàng"}`, type: "warning" });
    setHandover(o);
  }

  async function scan() {
    try { const { content } = await scanQRCode(); setCode(content); findByCode(content); }
    catch { /* người dùng đóng camera */ }
  }

  return (
    <Page className="page with-tabbar">
      <Header title="Bảng đơn của quán" showBackIcon={false} />
      <Tabs activeKey={tab} onChange={setTab}>
        <Tabs.Tab key="orders" label="Đơn hôm nay">
          <Box className="section">
            <Text.Title size="small">Giao món</Text.Title>
            <div className="code-entry">
              <Input type="number" inputMode="numeric" maxLength={4} placeholder="Nhập mã 4 số" value={code} onChange={(e) => setCode(e.target.value.slice(0, 4))} />
              <Button variant="secondary" onClick={scan} aria-label="Quét QR">Quét QR</Button>
              <Button disabled={code.length !== 4} onClick={() => findByCode(code)}>Tìm</Button>
            </div>
          </Box>

          {data && (
            <Box className="section">
              <div className="row-between"><Text.Title size="small">Cần chuẩn bị hôm nay</Text.Title><Text size="xSmall" className="muted">cập nhật {data.serverTime}</Text></div>
              {data.prepSummary.length ? data.prepSummary.map((p) => (
                <div className="row-between prep" key={p.menu_item_id}><Text>{p.name}</Text><Text.Title size="small">{p.quantity}</Text.Title></div>
              )) : <Text size="small" className="muted">Chưa có đơn đã thanh toán.</Text>}
            </Box>
          )}

          {data && !data.orders.length && <Empty title="Chưa có đơn nào" hint="Đơn đã thanh toán sẽ tự hiện ở đây, không cần tải lại." />}

          {bySlot.map(([slot, orders]) => (
            <Box className="section" key={slot}>
              <Text.Title size="small" className="slot-title">{slot} · {orders.length} đơn</Text.Title>
              {orders.map((o) => (
                <div className={`board-card ${fresh.has(o.id) ? "is-new" : ""}`} key={o.id}>
                  <div className="row-between">
                    <Text.Title size="normal">#{o.code}</Text.Title>
                    <StatusBadge status={o.status} />
                  </div>
                  <Text size="small" className="muted">{o.customerName} · {vnd(o.total)}</Text>
                  {o.needsStockConfirm && <Banner tone="warning">Thanh toán về trễ sau khi hết giữ món — kiểm tra lại tồn trước khi làm.</Banner>}
                  <ul className="board-items">
                    {o.items.map((i) => <li key={i.menuItemId}><b>{i.quantity}×</b> {i.name}{i.note && <em> — {i.note}</em>}</li>)}
                  </ul>
                  <div className="board-actions">
                    {NEXT[o.status] && <Button size="small" loading={busy === o.id} onClick={() => move(o, NEXT[o.status].to)}>{NEXT[o.status].label}</Button>}
                    {o.status === "ready" && <Button size="small" onClick={() => setHandover(o)}>Giao món</Button>}
                    {["paid", "preparing"].includes(o.status) && <Button size="small" variant="tertiary" type="danger" onClick={() => { setCancelFor(o); setReason(""); }}>Huỷ đơn</Button>}
                    {o.status === "ready" && <Button size="small" variant="tertiary" onClick={() => move(o, "no_show")}>Không đến</Button>}
                  </div>
                </div>
              ))}
            </Box>
          ))}
        </Tabs.Tab>
        <Tabs.Tab key="stock" label="Kho món">
          <StockTab data={data} reload={load} canEdit={user?.role === "manager"} />
        </Tabs.Tab>
      </Tabs>

      <HandoverModal order={handover} initialCode={code} onClose={() => setHandover(null)}
        onConfirm={async (c) => { if (await move(handover, "picked_up", { code: c })) { openSnackbar({ text: `Đã giao đơn #${handover.code}`, type: "success" }); setHandover(null); setCode(""); } }} />

      <Modal visible={!!cancelFor} title={`Huỷ đơn #${cancelFor?.code}`} onClose={() => setCancelFor(null)}
        description="Khách sẽ thấy lý do huỷ. Quán cần hoàn tiền thủ công cho đơn này (BR-08)."
        actions={[{ text: "Đóng", close: true }, { text: "Huỷ đơn", danger: true, onClick: async () => { if (!reason.trim()) return openSnackbar({ text: "Nhập lý do huỷ", type: "warning" }); if (await move(cancelFor, "cancelled_by_store", { reason })) setCancelFor(null); } }]}>
        <Input placeholder="Lý do (vd: hết nguyên liệu)" value={reason} maxLength={100} onChange={(e) => setReason(e.target.value)} />
      </Modal>
    </Page>
  );
}

// Giao món: bắt buộc nhập/quét đúng mã (US-08)
function HandoverModal({ order, initialCode, onClose, onConfirm }) {
  const [c, setC] = useState("");
  useEffect(() => { setC(initialCode === order?.code ? initialCode : ""); }, [order, initialCode]);
  return (
    <Modal visible={!!order} title={`Giao đơn #${order?.code}`} onClose={onClose}
      description={order ? order.items.map((i) => `${i.quantity}× ${i.name}`).join(", ") : ""}
      actions={[{ text: "Đóng", close: true }, { text: "Xác nhận đã giao", highLight: true, onClick: () => onConfirm(c) }]}>
      <Input type="number" inputMode="numeric" placeholder="Nhập mã khách đưa" value={c} onChange={(e) => setC(e.target.value.slice(0, 4))} />
    </Modal>
  );
}

function StockTab({ data, reload, canEdit }) {
  const { openSnackbar } = useSnackbar();
  if (!data) return null;
  async function save(id, payload) {
    try { await Api.setStock(id, payload); reload(); } catch (e) { openSnackbar({ text: e.message, type: "error" }); }
  }
  return (
    <Box className="section">
      {!canEdit && <Banner tone="neutral">Chỉ quản lý được chỉnh số phần.</Banner>}
      {data.stock.map((s) => (
        <div className="stock-row" key={s.id}>
          <div>
            <Text>{s.name}</Text>
            <Text size="xSmall" className="muted">{vnd(s.price)} · đã bán {s.portions_total - s.portions_left}/{s.portions_total}</Text>
          </div>
          <div className="stock-ctrl">
            <Stepper value={s.portions_left} max={999} disabled={!canEdit} onChange={(v) => save(s.id, { portionsLeft: Math.max(0, v) })} />
            <Switch label="Hết" checked={s.sold_out} disabled={!canEdit} onChange={(e) => save(s.id, { soldOut: e.target.checked })} />
          </div>
        </div>
      ))}
    </Box>
  );
}
