import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Box, Button, Header, Input, Page, Sheet, Text, useNavigate, useSnackbar } from "zmp-ui";
import { Api } from "../lib/api";
import { vnd } from "../lib/format";
import { startPayment } from "../lib/payment";
import { useCart } from "../state/cart";
import { useSession } from "../state/session";
import { Banner, DishImage, Empty, Stepper } from "../components/ui";

// S2 Cart & Payment — states: empty cart, slot full, price changed, paying
export default function CartPage() {
  const nav = useNavigate();
  const { openSnackbar } = useSnackbar();
  const cart = useCart();
  const { user } = useSession();
  const [menu, setMenu] = useState(null);
  const [slots, setSlots] = useState(null);
  const [notice, setNotice] = useState(null); // { tone, text }
  const [paying, setPaying] = useState(false);
  const [mockOrder, setMockOrder] = useState(null);

  const load = useCallback(async () => {
    try {
      const [m, s] = await Promise.all([Api.menu(), Api.slots()]);
      setMenu(m); setSlots(s);
      // Đồng bộ giá mới vào giỏ trước khi trả tiền (US-03)
      const changed = [];
      m.items.forEach((i) => { const l = cart.cart.lines[i.id]; if (l && l.price !== i.price) { changed.push(`${i.name}: ${vnd(l.price)} → ${vnd(i.price)}`); cart.setPrice(i.id, i.price); } });
      if (changed.length) setNotice({ tone: "warning", text: `Giá đã cập nhật — ${changed.join("; ")}` });
      if (cart.cart.slotId && s.find((x) => x.id === cart.cart.slotId)?.disabled) cart.setSlot(null);
    } catch (e) { setNotice({ tone: "danger", text: e.message }); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => { load(); }, [load]);

  const stockOf = useMemo(() => Object.fromEntries((menu?.items || []).map((i) => [i.id, i])), [menu]);
  const maxQty = menu?.maxQtyPerDish || 5;

  async function pay() {
    if (!cart.cart.slotId) { setNotice({ tone: "warning", text: "Vui lòng chọn giờ nhận món trước khi thanh toán" }); return; } // TC-03
    setPaying(true); setNotice(null);
    try {
      const order = await Api.createOrder({
        slotId: cart.cart.slotId,
        items: cart.lines.map((l) => ({ menuItemId: l.id, quantity: l.quantity, note: l.note || undefined, expectedPrice: l.price })),
      });
      const { mode } = await startPayment(order.id);
      if (mode === "mock") { setMockOrder(order); return; }
      nav(`/result/${order.id}?justPaid=1`, { replace: true });
    } catch (e) {
      handleOrderError(e);
    } finally {
      setPaying(false);
    }
  }

  function handleOrderError(e) {
    const b = e.body || {};
    if (e.code === "PRICE_CHANGED") {
      b.priceChanges.forEach((p) => cart.setPrice(p.menuItemId, p.newPrice));
      setNotice({ tone: "warning", text: `Giá đã thay đổi: ${b.priceChanges.map((p) => `${p.name} ${vnd(p.newPrice)}`).join(", ")}. Kiểm tra lại tổng tiền rồi thanh toán.` });
    } else if (e.code === "OUT_OF_STOCK") {
      setNotice({ tone: "danger", text: `${b.message} — bạn chưa bị trừ tiền. Hãy giảm số lượng hoặc bỏ món này.` });
      load();
    } else if (["SLOT_FULL", "SLOT_TOO_SOON"].includes(e.code)) {
      cart.setSlot(null);
      setNotice({ tone: "danger", text: `${b.message} — bạn chưa bị trừ tiền.` });
      load();
    } else {
      setNotice({ tone: "danger", text: e.message });
    }
  }

  async function mockResult(result) {
    const order = mockOrder;
    setMockOrder(null);
    try { await Api.mockPay(order.id, result); } catch (e) { openSnackbar({ text: e.message, type: "error" }); }
    nav(`/result/${order.id}?justPaid=1`, { replace: true });
  }

  if (!cart.lines.length && !mockOrder)
    return (
      <Page className="page with-tabbar">
        <Header title="Giỏ hàng" showBackIcon={false} />
        <Empty title="Giỏ hàng đang trống" hint="Chọn món ở thực đơn, bạn sẽ thấy tổng tiền tại đây." action={<Button variant="secondary" onClick={() => nav("/")}>Xem thực đơn</Button>} />
      </Page>
    );

  const closed = menu && !menu.open;

  return (
    <Page className="page with-tabbar with-paybar">
      <Header title="Giỏ hàng" showBackIcon={false} />
      {closed && <Banner tone="warning">{menu.message}</Banner>}
      {notice && <Banner tone={notice.tone}>{notice.text}</Banner>}

      <Box className="section">
        {cart.lines.map((l) => {
          const s = stockOf[l.id];
          const max = Math.min(maxQty, s ? s.portionsLeft + 0 : maxQty);
          const unavailable = s && s.soldOut;
          return (
            <div className="cart-line" key={l.id}>
              <DishImage src={l.imageUrl} alt={l.name} className="small" />
              <div className="cart-line-body">
                <div className="row-between">
                  <Text.Title size="small">{l.name}</Text.Title>
                  <Text className="price">{vnd(l.price * l.quantity)}</Text>
                </div>
                <Text size="xSmall" className={unavailable ? "text-danger" : "muted"}>
                  {unavailable ? "Hết món — vui lòng bỏ khỏi giỏ" : `${l.quantity} × ${vnd(l.price)}`}
                </Text>
                <Input size="small" className="note" placeholder="Ghi chú (vd: không hành, ít cay)" maxLength={100} value={l.note} onChange={(e) => cart.setNote(l.id, e.target.value)} />
                <div className="row-between">
                  <button type="button" className="link-danger" onClick={() => cart.setQty(l.id, 0)}>Bỏ món</button>
                  <Stepper value={l.quantity} max={Math.max(1, max)} onChange={(q) => cart.setQty(l.id, Math.min(q, Math.max(1, max)))} />
                </div>
              </div>
            </div>
          );
        })}
      </Box>

      <Box className="section">
        <Text.Title size="small">Giờ nhận món</Text.Title>
        <Text size="xSmall" className="muted">Mỗi khung 15 phút. Khung đã đủ đơn hoặc bắt đầu trong 30 phút tới sẽ bị khoá.</Text>
        <div className="chips">
          {(slots || []).map((s) => (
            <button key={s.id} type="button" disabled={s.disabled}
              className={`chip ${cart.cart.slotId === s.id ? "active" : ""}`}
              onClick={() => cart.setSlot(s.id)}
              aria-pressed={cart.cart.slotId === s.id}>
              <span>{s.start}</span>
              <small>{s.disabledReason === "full" ? "Đã đủ" : s.disabledReason === "too_soon" ? "Quá gần" : `Còn ${s.remaining}`}</small>
            </button>
          ))}
          {!slots && <Text size="small" className="muted">Đang tải khung giờ…</Text>}
        </div>
      </Box>

      <Box className="section">
        <Text.Title size="small">Thanh toán</Text.Title>
        <div className="row-between"><Text className="muted">Phương thức</Text><Text>ZaloPay / chuyển khoản</Text></div>
        <div className="row-between"><Text className="muted">Người nhận</Text><Text>{user?.name || "Khách"}</Text></div>
        <div className="row-between total"><Text.Title size="small">Tổng cộng</Text.Title><Text.Title size="small">{vnd(cart.total)}</Text.Title></div>
        <Text size="xxSmall" className="muted">Đơn được giữ món 10 phút để bạn hoàn tất thanh toán. Cần huỷ? Báo quán trước 10:30 để được hoàn tiền.</Text>
      </Box>

      <div className="pay-bar">
        <Button fullWidth loading={paying} disabled={paying || closed || !cart.lines.length} onClick={pay}>
          {paying ? "Đang tạo thanh toán…" : `Thanh toán ${vnd(cart.total)}`}
        </Button>
      </div>

      {/* Chỉ xuất hiện khi server chạy PAYMENT_MODE=mock (bản thử nghiệm nội bộ) */}
      <Sheet visible={!!mockOrder} onClose={() => mockResult("fail")} autoHeight mask handler swipeToClose title="Thanh toán thử nghiệm">
        <Box className="sheet-body">
          <Text className="muted">Môi trường sandbox — không trừ tiền thật. Đơn #{mockOrder?.code} · {vnd(mockOrder?.total)}</Text>
          <Button fullWidth onClick={() => mockResult("success")}>Giả lập thanh toán thành công</Button>
          <Button fullWidth variant="tertiary" onClick={() => mockResult("fail")}>Giả lập thanh toán thất bại</Button>
        </Box>
      </Sheet>
    </Page>
  );
}
