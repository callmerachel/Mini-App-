# Mini App — xem hướng dẫn đầy đủ ở ../README.md

```bash
cp .env.example .env   # điền APP_ID, VITE_API_URL
npm install
npm run login
npm run deploy         # chọn Testing
```
