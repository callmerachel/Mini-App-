import { defineConfig } from "vite";
import zaloMiniApp from "zmp-vite-plugin";
import react from "@vitejs/plugin-react";

// https://vitejs.dev/config/
export default () => {
  return defineConfig({
    root: "./src",
    base: "",
    envDir: process.cwd(), // đọc .env ở thư mục gốc dự án (chung file với APP_ID của zmp-cli)
    plugins: [zaloMiniApp(), react()],
    build: {
      assetsInlineLimit: 0,
    },
  });
};
